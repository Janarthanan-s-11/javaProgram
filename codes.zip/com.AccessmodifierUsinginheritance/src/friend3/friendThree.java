package friend3;
//To import a package to another package, use import packagename.classname
import givenPenToFriends.whomNeedtoGive;

public class friendThree {

	public static void main(String[] args) {
		
		whomNeedtoGive NeedPen = new whomNeedtoGive();
		NeedPen.friend2(); //PUBLIC MODIFIER
	}

}
