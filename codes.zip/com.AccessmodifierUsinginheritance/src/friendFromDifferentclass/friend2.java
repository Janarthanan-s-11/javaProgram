package friendFromDifferentclass;

import givenPenToFriends.whomNeedtoGive;

public class friend2 extends whomNeedtoGive {

	public static void main(String[] args) {
		
		friend2 SuperMan = new friend2();
		SuperMan.friend2(); //PUBLIC MODIFIER
		SuperMan.friend4(); //PROTECTED MODIFIER
	
	

	}

}
