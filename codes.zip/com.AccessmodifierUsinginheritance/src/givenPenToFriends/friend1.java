package givenPenToFriends;

public class friend1 extends whomNeedtoGive{

	public static void main(String[] args) {
		
		friend1 ironman = new friend1();
		
		ironman.friend1(); //DEFAULT MODIFIER
		ironman.friend2(); //PUBLIC MODIFIER
		ironman.friend4(); //PROTECTED MODIFIER
	}

}
