//Need to give pen to close friends of same class room
package givenPenToFriends;
//create a class
public class whomNeedtoGive {
	String pen1color = "blue";
	public String penName = "cello";	
	private String pen2color = "black";
	//Default modifier : WE CAN USE WITHIN PACKAGE
	void friend1(){
		System.out.println("Give "+penName+" to friend 1 where the color of the pen is "+pen1color+" or "+pen2color);
	}
	//public : WE CAN USE THIS method FOR ANOTHER PACKAGE WITHOUT INHERITANCE(EXTENDS)
	public void friend2(){
		System.out.println("Give "+penName+" to friend 2 where the color of the pen is "+pen1color+" or "+pen2color);
	}
	//private : WE CAN USE WITHIN THIS CLASS
	private void friend3(){
		System.out.println("Give "+penName+" to friend 3 where the color of the pen is "+pen1color+" or "+pen2color);
	}
	//protect : WE CAN USE THIS TO ANOTHER PACKAGE ONLY WITH INHERITANCE(EXTENDS)
	protected void friend4(){
		System.out.println("Give "+penName+" to friend 4 where the color of the pen is "+pen1color+" or "+pen2color);
	}
public static void main(String[] args) {
	whomNeedtoGive Antman = new whomNeedtoGive();
	Antman.friend1();
	Antman.friend2();
	Antman.friend3();
	Antman.friend4();	
}
}

