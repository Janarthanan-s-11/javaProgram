package checkoddandevennumber;

public class oddOrEven {
	
	int number = 3;
	int value = number%2;
	
	public void action() {
		if(value==0) {
			System.out.println("Given number is even");
			}
		else {
			System.out.println("Given number is Odd");
		}
		
	}
	

	public static void main(String[] args) {
		oddOrEven result = new oddOrEven();
		result.action();

	}

}
