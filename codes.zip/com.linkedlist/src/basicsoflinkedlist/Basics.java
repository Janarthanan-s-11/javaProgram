package basicsoflinkedlist;

import java.util.LinkedList;
import java.util.List;

//linked list is use to perform insert or delete operation as simple.
public class Basics {

	public static void main(String[] args) {
		//linkedlist<generic> linkedlist name = new lnkedlist()<>;
		LinkedList<Integer> runs = new LinkedList<Integer>();
		runs.add(1);
		runs.add(6);
		runs.add(0);
		runs.add(2);
		runs.add(0);
		runs.add(4);
		runs.add(1);
		runs.add(6);
		runs.add(0);
		runs.add(2);
		runs.add(0);
		runs.add(4);
		System.out.println(runs);
		runs.addFirst(6); // to add element at beginning
		runs.addLast(1); //to ad element at last
		System.out.println(runs);
		System.out.println("Get first element by get first "+runs.getFirst()); //to get first element
		System.out.println("Get first element by normal index method "+runs.get(0)); //to get last element
		System.out.println("Get first element by peek method "+runs.peekFirst());
		System.out.println("To remove first element "+runs.removeFirst());
		System.out.println("To remove last element "+runs.removeLast());
		System.out.println("Remove first element using poll "+runs.poll()); //poll will delete the element
		System.out.println("Remove last element using poll "+runs.pollLast());
		System.out.println("Current value of linked list "+runs);
		//o is repeated element in the list, to remove first 0 or last 0 we need to use occurance
		System.out.println("Remove 0 which is present for first time "+runs.removeFirstOccurrence(0));
		System.out.println("Remove 0 which is present for last time "+runs.removeLastOccurrence(0));
		System.out.println("Current value of linked list "+runs);
		
		

	}

}
