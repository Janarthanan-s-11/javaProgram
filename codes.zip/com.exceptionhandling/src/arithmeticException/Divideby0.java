package arithmeticException;

public class Divideby0 {

	public static void main(String[] args) {
		try {
			int Number1 = 10;
			int Number2 = 0;
			int result = Number1/Number2;
			System.out.println(result);			
		}catch (NullPointerException e) {
			System.out.println("This is nullpointer exception");	
		}catch (ArithmeticException e) {
			System.out.println("This is arithmetic exception");	
		}
		//WE if don't know the exception type, then we can simply write catch(exception e)
		//exception is the highest value compare to null and arithmetic exception
		//if program has exception, then it will not consider null and arithmetic, it directly call exception catch
		//eg:exception is 25kg back, but for 1kg of rice we can carry in 1kg bag, so we can use null or arithmetic

	}

}
