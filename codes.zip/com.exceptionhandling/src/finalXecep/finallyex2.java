package finalXecep;

public class finallyex2 {
	
		public int dummyfunction() {
			return 10;
		}
		public static void main(String[] args) {		
			try {
				System.out.println("Inside try block");
				throw new Exception();
			}catch (Exception e) {
				System.out.println("Inside catch block");
			}finally {
				System.out.println("Inside finally block");
			}
		}
	//whenever try block get executed, finally block will automatically executed
	//Here there is we have manually triggered one exception so catch block executed
	}


	

