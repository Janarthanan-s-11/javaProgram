package finalXecep;

public class finalexample {

	public int dummyfunction() {
		return 10;
	}
	public static void main(String[] args) {
		
		try {
			System.out.println("Inside try block");
		}catch (Exception e) {
			System.out.println("Inside catch block");
		}finally {
			System.out.println("Inside finally block");
		}

	}
//whenever try block get executed, finally block will automatically executed, when there is no exception
//Here there is no exception so catch block doesn't displayed	
}
