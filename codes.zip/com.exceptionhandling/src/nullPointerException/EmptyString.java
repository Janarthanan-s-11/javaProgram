package nullPointerException;

public class EmptyString {
	static String superhero;
	public static void main(String[] args) {
	try {
		
		System.out.println(superhero.length());
	}catch(ArithmeticException e) {
		System.out.println("This is arithmetic exception");
	}catch (NullPointerException e) {
		System.out.println("This is nullpointer exception");
	}
	//If string doesn't have a value and when user try to perform string operation for it, Then it is nullpointer exception
	}

}
