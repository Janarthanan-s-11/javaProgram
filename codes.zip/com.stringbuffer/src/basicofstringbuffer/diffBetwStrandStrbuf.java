package basicofstringbuffer;

public class diffBetwStrandStrbuf {
//string will support both new keyword and literal
//string buffer will only support new keyword
	public static void main(String[] args) {
	//string object = new string("value")
String name = new String("jeff");
//perform ADD, Concat in string, appends in string buffer
System.out.println(name.concat("hardy"));
System.out.println("As per the string, now the value of name is "+name);
//string is immutable, which is constant

//stringbuffer s = new stringbuffer("value")
StringBuffer name1 = new StringBuffer("jeff");
System.out.println(name1.append("hardy"));
System.out.println("As per the stringbuffer, now the value of name1 is "+name1);
//string buffer is mutable, which is variable, also is is sequence(synchronized)
//we can't reverse string, we can only reverse the string buffer---IMPORTANT
	}

}
