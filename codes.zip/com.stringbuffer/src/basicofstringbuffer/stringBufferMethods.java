package basicofstringbuffer;

public class stringBufferMethods {
//reverse, replace, delete, capacity,charAt, substring(crop), length, insert
	public static void main(String[] args) {
	//string buffer only support new keyword, create new keyword
		//Stringbuffer s = new Stringbuffer("value");
		StringBuffer favAnimal = new StringBuffer("dog");
		StringBuffer Action = new StringBuffer("Bark") ;
		//reverse
		System.out.println("Reverse = "+favAnimal.reverse());
		//replace
		System.out.println("Replace of dog is "+Action.replace(0, 1, "D"));
		//delete
		System.out.println("delete r from dark "+Action.delete(2, 3));
		//capacity-- it will tell the capacity of stringbuffer - favAnimal and action, default value is 20
		System.out.println("Capacity of Action is "+Action.capacity()+" "+"Capacity of favAnimal is "+favAnimal.capacity());
		//charAt
		System.out.println("CharAt 1 of Action is "+Action.charAt(1)+" "+"CharAt 1 of favAnimal is "+favAnimal.charAt(1));
		//substring--now value of action is dak and fav animal is god
		System.out.println("Substring 2 from Action is "+Action.substring(1, 3)+" "+"Substring 2 from favAnimal is "+favAnimal.substring(1, 3));
		//length
		System.out.println("Length of Action is "+Action.length()+" "+"Length of favAnimal is "+favAnimal.length());
		//insert
		System.out.println("Insert r in Action = "+Action.insert(2, 'r'));
	}

}
