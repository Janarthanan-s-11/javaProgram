//static is mainly used for memory management
//need mileage, top speed, name of the vehicle using static method, block and variable
package learnstaticmethod;

public class BasicexamplevehicleDetails {
	
	//static variables
	static int topSpeed = 145;	
	static String Bike = "Apache200";
	static int mileage = 35;
	//static block
	static {
		System.out.println("The mileage of "+Bike+"is "+mileage);
	}
	//static method
	
	public static void Details() {
		System.out.println("Top speed of "+Bike+"is "+topSpeed);
	}
	
	public static void main(String[] args) {
		//static block, variables can be execute without creating the main method, only static method alone need main method,
		//static keyword(block,variables,method,class) no need object
		Details();

	}

}
