package learnstaticmethod;
//need to credit equal salary for all workers for this month, even thought they get less or more pay.
//Also need to notify them, we have deducted 5000 from all employee
public class exampleForStaticKeywords {
	//Create a variable
	String empName;
	//create a static variable
	static int salary = 5000;
	//Create a static keyword
	static {
		System.out.println("salary will be credited by deducting "+salary);
	}
	public static void main(String[] args) {

exampleForStaticKeywords creditedSalary1 = new exampleForStaticKeywords();
exampleForStaticKeywords creditedSalary2 = new exampleForStaticKeywords();
exampleForStaticKeywords creditedSalary3 = new exampleForStaticKeywords();
creditedSalary1.empName = "Spiderman";
creditedSalary1.salary = 20000;
creditedSalary2.empName = "Batman";
creditedSalary2.salary = 50000;
creditedSalary3.empName = "Ant-man";
creditedSalary3.salary = 25000;
System.out.println("Name "+creditedSalary1.empName+" salary "+creditedSalary1.salary);
System.out.println("Name "+creditedSalary2.empName+" salary "+creditedSalary2.salary);
System.out.println("Name "+creditedSalary3.empName+" salary "+creditedSalary3.salary);
//static variable will always consider the latest value given to it.
//static variable is not only for a specific object, it is common to all.
	}
}
