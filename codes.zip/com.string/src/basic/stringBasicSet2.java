package basic;
import basic.stringbasicSet1;
public class stringBasicSet2 extends stringbasicSet1 {

	public static void main(String[] args) {
//1.datatype to string
		System.out.println("1. datatype to string is "+String.valueOf(cruisingSpeed));
		System.out.println("2. value to int is "+cc); //default value  int is null
		System.out.println("3. value to int to string is "+String.valueOf(cc));//because 0 only saving as string here
//join with delimiter
		System.out.println("4. Join with delimiter");
		System.out.println(String.join("/", "11", "07", "1998"));
		//split
		String reason = "I'm, Fine"; //--create a string
		String[] splitresult = reason.split(",");//---map the string to new string[]
		for(String string:splitresult) {    //---using create another string then map in for, to split and print
			System.out.println("5.split " +string);
		}
		
	}

}
