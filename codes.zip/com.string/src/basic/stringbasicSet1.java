package basic;
//variables are two types--global variable and local variable. static is global variable, variable present inside class in local variable
public class stringbasicSet1 {
	//string should be declare inside the main method
	 //HINT- ALWAYS BEGIN INDEX WILL INC and END index will EXC
	//here we are created one string and data type(int)
	static int cruisingSpeed = 140;//---global variable
	static int cc;

	//Two types of string 
	static String bikeName = "KTMAdventure390";//string literal----local variable//global variable
	static String Brand = new String(" KTM ");// STRING KEYWORD----local variable//------global variable
	public static void main(String[] args) {
				String space = " ";  	//---local variable
//no need to create object here
//1.Length of the char
		System.out.println("1.length "+bikeName.length());
//2.to find the value of the given index
		System.out.println("2. Value of index is "+Brand.charAt(2));		
//3.to find the position of the given value
		System.out.println("3. position of the value is "+bikeName.indexOf('e'));
//4.to find the position of 2nd e in bikename
		System.out.println("4. Position of 2nd E, which value of the index by char is "+bikeName.indexOf('e', 7)); //begin from 7th index
//5.is equal -- will check case sensitive
		System.out.println("5. Equals "+Brand.equals("KTm"));
//6. is equal but not case sensitive
		System.out.println("6. check "+Brand.equalsIgnoreCase("KTm"));
//7.Upper and lower
		System.out.println("7. lowertoUpper "+bikeName.toUpperCase());
		System.out.println("8. UpperTolower "+bikeName.toLowerCase());
//9.Replace value of the index
		System.out.println("9. Replace "+bikeName.replace('3', '4'));
//10.Contains or not by comparing two string and within the string
		System.out.println("10. Contains or not by comparing two string "+bikeName.contains(Brand));//method overloading
		System.out.println("11. Contains or not with the string "+bikeName.contains("Adven"));//method overloading
//12.Crop or substring
		System.out.println("12. Crop from index 7 is "+bikeName.substring(7));
		System.out.println("13. Crop in between index 3 and 9 is "+bikeName.substring(3,9));
//14.Concate or add or appends
		System.out.println("14. add two string "+bikeName.concat(Brand));//method overloading
		System.out.println("15. add within the string "+bikeName.concat("x"));//method overloading
//16.Remove space or string
		System.out.println("16.remove space "+Brand.trim());
//17.Is empty - The isEmpty operator checks if a string contains no characters and is only whitespace. 
		System.out.println("17.is empty "+space.isEmpty());
//18. Is blank - The isBlank operator checks if a string contains no characters, is only whitespace, and is null.
		System.out.println("18.is blank "+space.isBlank());
		
	}
//we no need object for string, because string itself an object
}
