package treesetbasics;

import java.util.Iterator;
import java.util.TreeSet;

//Treeset will store element in ascending order and will not allow heterogeneous storing(multiple data types)
//Treeset will not allow user to store null element after version 1.6
//why null not allowed? because tree will always compare the value and store, we can't compare null value.
public class BasicOperations {

	public static void main(String[] args) {
		TreeSet<Integer> numbers = new TreeSet<Integer>();
		numbers.add(10);
		numbers.add(1);
		numbers.add(11);
		numbers.add(5);
		numbers.add(0);
		numbers.add(7);
  System.out.println("Input "+numbers); //will store element in ascending order
  System.out.println("Descending order "+numbers.descendingSet());
  System.out.println("To get lower value to the give input in the set "+numbers.headSet(5));
  System.out.println("To get higher value of given input in the set is "+numbers.tailSet(5));//will include the input also
  System.out.println("To get inbetween value of given input in the set is "+numbers.subSet(5, 10));//will include the input also
	System.out.println("To remove the first value of the element "+numbers.pollFirst());
	//comparator will return null, if the set is arrange in default order, if it arrange in user defined order, then it will display respective result
	System.out.println("To check whether the set is arrange in ascending order "+numbers.comparator());
	Iterator<Integer> ascending = numbers.iterator();
	while(ascending.hasNext()) {
		System.out.println("Print in ascending order "+ ascending.next());
	}
	//to iterate in descending
	Iterator<Integer> reverseOrder = numbers.descendingIterator();
	while (reverseOrder.hasNext()) {
		System.out.println("Print in descending order "+reverseOrder.next());
	}
			
	}	
	
	}
	
	


