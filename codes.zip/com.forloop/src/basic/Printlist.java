package basic;

import java.util.ArrayList;
import java.util.List;

public class Printlist extends printname {

	public static void main(String[] args) {
		List<String> names = new ArrayList<String>();
		names.add("Spiderman");
		names.add("Ironman");
		System.out.println(names);
		for(String string : names) {
			System.out.println(string);
		}

	}

}
