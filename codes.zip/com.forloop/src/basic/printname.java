package basic;

//print batman for 5 times using for loop

public class printname {
	static int numberOfTimes = 4;
	public static void main(String[] args) {
	
		//for (initialExpression; testExpression; updateExpression) {
	    // body of the loop   }
		
	
	for (numberOfTimes=0; numberOfTimes<4; numberOfTimes++) {
		// 0 ; 0<4; print++
		//1; 1<4;print++
		//2; 2<4; print++
		//3; 3<4; print++
		//4; 4<4 condition failed
		System.out.println("Batman");
	}

}
}
