package com.consoverload;

public class Draw {
	String draw;
	Boolean DrawYes;
	//create a no arg constructor
	Draw(){
		System.out.println("draw anything");
	}
	//create a parameterized constructor
	Draw(String Drawing){
		
		draw=Drawing;
		System.out.println("Draw a circle");
	}
	//Create a another parameterized constructor with boolean
	Draw(Boolean YesNo){
		DrawYes = YesNo;
		System.out.println(true);
	}	
	public static void main(String[] args) {
	Draw draw = new Draw();
	//This object will call no args
	Draw draw1= new Draw("Circle");
	//This object will call parameterized
	Draw DrawOrNot = new Draw(false);
	//This object will call parameterized Boolean

	}

}
