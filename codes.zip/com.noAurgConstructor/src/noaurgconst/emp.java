package noaurgconst;

public class emp {
	
	String empName;
	int empId;
	
	emp(){
		empName = "spiderman";
		empId = 1;
		System.out.println("Emp obj is created");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		emp EMP = new emp();

	}

}
