module com.noAurgConstructor {
}