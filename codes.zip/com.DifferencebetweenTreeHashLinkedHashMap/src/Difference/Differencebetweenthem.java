package Difference;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class Differencebetweenthem {

	public static void main(String[] args) {
		TreeMap<String, String> moviesUsingTreemap = new TreeMap<String, String>();
		moviesUsingTreemap.put("Leo", "Vijay");
		moviesUsingTreemap.put("Valimai", "Ajith");
		moviesUsingTreemap.put("Jailer", "Rajini");
		moviesUsingTreemap.put("Vikram", null); // will not allow null key,because map will always work based on key
		moviesUsingTreemap.put("Vikram", "Kamal");
		//moviesUsingTreemap.put(null, "Kamal");
		System.out.println("Output of Treemap "+moviesUsingTreemap); //will maintain natural order
		
		LinkedHashMap<String, String> MoviesUsingLinkedHashmap = new LinkedHashMap<String, String>();
		MoviesUsingLinkedHashmap.put("Leo", "Vijay");
		MoviesUsingLinkedHashmap.put("Valimai", "Ajith");
		MoviesUsingLinkedHashmap.put("Jailer", "Rajini");
		MoviesUsingLinkedHashmap.put(null, "Vikram"); //will allow null key
		MoviesUsingLinkedHashmap.put(null, "Kaththi"); //Duplicate value will get replaced
		System.out.println("Output of Linkedhashmap "+MoviesUsingLinkedHashmap); //will maintain insertion order

		HashMap<String, String> MoviesUsingHashmap = new HashMap<String, String>();
		MoviesUsingHashmap.put("Leo", "Vijay");
		MoviesUsingHashmap.put("Valimai", "Ajith");
		MoviesUsingHashmap.put("Jailer", "Rajini");
		MoviesUsingHashmap.put(null, "Kaththi"); //will allow null key
		MoviesUsingLinkedHashmap.put(null, "Vikram");//Will not consider duplicate value
		System.out.println("Output of hashmap "+MoviesUsingHashmap); //will not maintain order

	}

}
