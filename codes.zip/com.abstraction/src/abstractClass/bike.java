//1.All bike should have engine and Name
package abstractClass;

public abstract class bike {
//Declare method, then create child class to use this method in different bike brands
	//Now all bike having there own names, so now we can remove name method here,to remove we need to change class into abstract class
	//to remove it, we need to convert the methods name into abstract.
	public void engine() {
		System.out.println("Engine is 373cc");
	}
	//public void Name() {
		//System.out.println("400 cc bike");
	//}
	public abstract void Name();
	//it class has one abstract method, then class should also be abstract
	
	
}
// we can't create object for abstract class, because object can be created only when class perform any action completely.
//but abstract class can't complete any action, so we should not create an object for it. 
//This is 50% abstract class.