package abstractClass;
//NOW KTM MAYE HAVE DIFFERENT BIKE, SO BY USING OVERRIDING WE NEED TO CHANGE CHANGE BIKE NAME
public class KTM extends bike{
	 @Override
	public void engine() {
		System.out.println("Engine is 399cc");
	}
	 @Override //----- override is only for our hint.
	public void Name() {
		System.out.println("Bike name is Duke 390");
	}
	public static void main(String[] args) {
		bike model = new KTM();
		model.engine();
		model.Name();


	}

}
