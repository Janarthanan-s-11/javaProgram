package abstractClass;

import interfaces.country;
import interfaces.vehicle;

//NOW BAJAJ MAYE HAVE DIFFERENT BIKE, SO BY USING OVERRIDING WE NEED TO CHANGE CHANGE BIKE NAME
//to access interface we need to sue implement keyword, we can access multiple interface under single class using cammo.
//By using interface we can perform multiple inheritance
public class bajaj extends bike implements vehicle,country{
//once we implement the interface then we need to perform any action for it's method
	
	 @Override
	public void Name() {
		System.out.println("Bike name is Dominar 400");
	}
	 public void brandName() {
		 System.out.println("Name of the brand is "+Nameofthebrand);
	 };
	public void countryName() {
		 System.out.println("India");
	 }
	public static void main(String[] args) {
		bike model = new bajaj();
		model.engine();
		model.Name();
vehicle Brand = new bajaj();
Brand.brandName();
country NameOfcountry = new bajaj();
NameOfcountry.countryName();
	}

}
//here we have used class,abstract class,interface,inheritance which means encapsulation, which means process of binding data & methods together into a single unit.
