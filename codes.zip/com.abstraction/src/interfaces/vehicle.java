package interfaces;

public interface vehicle {
      String  Nameofthebrand = "Bajaj";
      //by default this is public access modifier, static data type and final value.     
      void brandName();
}
  //100% abstract class