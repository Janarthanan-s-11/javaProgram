package interfaces;

public interface country {
  void countryName();
}
