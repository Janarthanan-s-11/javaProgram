package ifselseif;
//requirement, need to guess the fav drink of a person within 3 attempt or else they need to tell the answer
public class icanguessyourfavdrink {
	//1.person need to think there fav drink
	String drink = "tea";
	//2.need to try 3 times, to perform a operation we need function(method)
	public void favDrinkis() {
		//3.Need to check whether his fav drink is coffee by comparing the data type variable with our guess drink
		//4/drink=tea, which need to be elabrate inside function like drink.equals("tea")
		if(drink.equals("coffee")) {
			System.out.println("Person : Yes it's coffee, how you found it in 1st attempt");
		}
		//Hint - Equals will compare case sensitive also, if we need to ignore it, then we can use equalignorecase
		else if(drink.equalsIgnoreCase("boost")){
			System.out.println("Person : Wow correct, It's boost");			
		}
		else if (drink.equals("horlicks")) {
			System.out.println("Person: Good it's horlicks");			
		}
		else{
			System.out.println("Person : Sorry the correct answer is "+drink);
		}
		
	}
	public static void main(String[] args) {
		icanguessyourfavdrink favdrink = new icanguessyourfavdrink();
		favdrink.favDrinkis();

	}

}
