package ifelsestatement;

public class coffeeOrtea {
	//by default boolean value is false
	boolean coffee = true;

	public static void main(String[] args) {
		//1.Need to create object
		coffeeOrtea Available = new coffeeOrtea();
		//2.Need to create if condition to check whether coffee is available or not by using else
		if(Available.coffee) {// by default if value is true, EG:Available.coffee and Available.coffee==true, both are same
			System.out.println("Coffee is available");
		}
		else {
			System.out.println("Sorry only tea is available");
			}
		

	}

}
