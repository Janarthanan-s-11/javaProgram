package switchcase;

public class iCanGuessYourFavDrink {
	//Think a drink
	String drink = "tea";
	//create method to perform a operation
	public void YourFav() {
		
		switch (drink) {
		case "coffee":
			System.out.println("Person : Yes it's coffee, how you found it in 1st attempt ");
		case "boost":
			System.out.println("Person : Wow correct, It's boost");	
		case"horlicks":
			System.out.println("Person: Good it's horlicks");	
			
		default:
			System.out.println("Person : Sorry the correct answer is "+drink );
		}
		
	}
	

	public static void main(String[] args) {
		iCanGuessYourFavDrink YourFavDrink = new iCanGuessYourFavDrink();
		YourFavDrink.YourFav();

	}

}
