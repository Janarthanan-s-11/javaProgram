package difference;

public class paramtcons {
	int studentID;
	String studentName;
	paramtcons(int ID, String Name){
		studentID = ID; //here we are mapping a new variable to input
		studentName = Name; //here we are mapping a new variable to input
	}
	public void printID() {
		System.out.println("Student name "+studentName+" student ID "+studentID);
	}

	public static void main(String[] args) {
		paramtcons result1 = new paramtcons(1, "Superman");
		result1.printID();
		paramtcons result2 = new paramtcons(1, "Batman");
		result2.printID();
		paramtcons result3 = new paramtcons(1, "Aquaman");
		result3.printID();
		paramtcons result4 = new paramtcons(1, "Spiderman");
		result4.printID();
		paramtcons result5 = new paramtcons(1, "Antman");
		result5.printID();

	}

}
