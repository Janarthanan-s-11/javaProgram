package difference;

public class NoargConstructors {
	//constructor name should be similar to class name
	//Create ID card for student using no argument constructor
	int studentID1;
	String studentName1;
	int studentID2;
	String studentName2;
	int studentID3;
	String studentName3;
	int studentID4;
	String studentName4;
	int studentID5;
	String studentName5;
	NoargConstructors(){
	studentID1 = 1;
	studentName1 = "Superman";
	studentID2 = 2;
	studentName2 = "Batman";
	studentID3 = 3;
	studentName3 = "Aquaman";
	studentID4 = 4;
	studentName4 = "Spiderman";
	studentID5 = 5;
	studentName5 = "Antman";
	}
	public void printIDcart() {
		
	System.out.println("ID "+studentID1+" Name "+studentName1+ "Using no arg");
	System.out.println("ID "+studentID2+" Name "+studentName2+ "Using no arg");
	System.out.println("ID "+studentID3+" Name "+studentName3+ "Using no arg");
	System.out.println("ID "+studentID4+" Name "+studentName4+ "Using no arg");
	System.out.println("ID "+studentID5+" Name "+studentName5+ "Using no arg");
	}
	
	public static void main(String[] args) {
		NoargConstructors result = new NoargConstructors();
		result.printIDcart(); //here no of lines is big, it will affect performance, so we need to use parameterized constructor
		
		
	}

}
