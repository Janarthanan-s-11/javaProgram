package linkedhashsetbasics;

import java.util.LinkedHashSet;

//will maintain insertion order
public class Basics {

	public static void main(String[] args) {
		LinkedHashSet random = new LinkedHashSet();
		random.add(1);
		random.add(2);
		random.add("Cricket");
		random.add(10);
		random.add(2);
		random.add(1);
		System.out.println(random);
		
	}

}
