package basics;

import java.util.HashSet;
import java.util.Iterator;

public class HashsetBasics2 {

	public static void main(String[] args) {
		//to iterate set we have only iterate option, we doesn't have list iterate option for set
		HashSet<String> Names = new HashSet<String>();
	     
	      Names.add("Batman");
	      Names.add("1");
	      Names.add("Superman"); 
	      Names.add("2");
	      Names.add("AquaMan");
	      Names.add("3");
	      System.out.println("Initial input "+Names);
	      
	      Iterator<String>split = Names.iterator();
	      
	    	  while(split.hasNext()) {
	    		  System.out.println("Output after split is "+split.next());
	    	  }
	      
	      
	      
	}

}
