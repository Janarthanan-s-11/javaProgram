package basics;

import java.util.HashSet;

//SET - insertion Order will not maintain --due to hashcode
//      DUPLICATED NOT ALLOWED 
public class HashsetBasics {
//Easy to search a element
	public static void main(String[] args) {
	
		//syntax hashset varaible = new hashset();--- default size is 16 and fill ratio is 0.75
		//syntax hashset varaible = new hashset(int initialsize);--- size can be customized and fill ratio is 0.75
		//syntax hashset varaible = new hashset(int initialsize, float fullratio);--- both size and fill ratio can be customized
      HashSet<String> Names = new HashSet<String>();
     
      Names.add("Batman");
      Names.add("1");
      Names.add("Superman"); //will consider superman value as 1, even it is duplicate
      Names.add("Superman");//here add is behave like boolen, it check whether value is available already, if not it will not or else it will leave
      Names.add("2");
      Names.add("AquaMan");
      Names.add("3");
      System.out.println("Initial input "+Names); //Order will not maintain
      Names.remove("3");
      System.out.println("remove 3 from above "+Names);
      System.out.println("Check whether this set having Batman - "+Names.contains("Batman"));
      // to compare 2 hashset, we need to create new hashset and compare it
      HashSet<String> Names1 = new HashSet<String>();
      Names1.addAll(Names);
      System.out.println("Input of names1 is "+Names1);
      System.out.println("Check whether Names1 and names having same data - "+Names1.containsAll(Names));
      
	}

}
