package parameterCons;

public class EmpDetails {
	
	String empName;
	int empID;
	
	EmpDetails(String name,int ID ){
		empName = name;
		empID = ID;
		
	}
	//Create function for perform some operation
	public void empdata() {
		// operation is performed based on data type variable, not on paramEter variable
		System.out.println("employee name is "+empName+" "+"employee ID is "+empID);
	}

	public static void main(String[] args) {
		// create class for multiple emp
		EmpDetails emp1 = new EmpDetails("SpiderMan", 1);
		emp1.empdata();
		EmpDetails emp2 = new EmpDetails("ironMan", 2);
		emp2.empdata();		

	}

}
