//how do you talk with your parents, partner and god using overloading
package wayOfTalking;
public class typesOfTalking {
//need to create same method but with different parameters
	//for study purpose using default access modifier
	 void talk(parents talkStyle) {
		System.out.println("respect");
	}
	//methods will display error, need to create class for each method, then error will remove
  void talk(partner talkStyle) {
	  System.out.println("freedom");
	}
  void talk(god talkStyle) {
	  System.out.println("full freedom");
}
		public static void main(String[] args) {
		//need to create obj
		typesOfTalking style = new typesOfTalking();
		//to call parent method, need to create obj for it, same do for partner and god
		parents parents = new parents();
		partner partner = new partner();
		god god = new god();
		//map objects and methods
		style.talk(parents);
		style.talk(partner);
		style.talk(god);
	}
}
