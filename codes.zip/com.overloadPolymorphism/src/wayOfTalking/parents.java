package wayOfTalking;

public class parents {

	
}
