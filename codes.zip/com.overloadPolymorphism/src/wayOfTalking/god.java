package wayOfTalking;

public class god {

}
