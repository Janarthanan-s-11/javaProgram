package wayOfTalking;

public class partner {

}
