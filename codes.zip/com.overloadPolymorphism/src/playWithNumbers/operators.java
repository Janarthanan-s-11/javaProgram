package playWithNumbers;
public class operators {
	//create methods with same name but with different operations
     private int maths(int a, int b) {
    	 return a+b;
    	 // for return type we don't need void, we should enter the return type
    	 //data types hint--Int and long for numbers, long must have l in suffix
    	 //char and string for alphabets...//float and double for decimal, where float must have f in suffix
     }
 private long maths(int a, long b, int c) {
    	 return a*b*c;
     }
 private double maths(double a, float b) {
	 return a-b;
 }
 private double maths(int a, double c) {
	 return a%c;
 }
	public static void main(String[] args) {
		//create obj
		operators operators = new operators();
		
		System.out.println("Addition of numbers "+operators.maths(11, 12));
		System.out.println("Subtraction of numbers "+operators.maths(3.23, 1.13f));
		System.out.println("Multiplication of numbers "+operators.maths(20, 21l, 33));
				System.out.println("Reminder of numbers"+operators.maths(22, 4));		
	}

}
