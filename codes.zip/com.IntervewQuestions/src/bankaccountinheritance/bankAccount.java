//Write a Java program to create a class known as "BankAccount" with methods called deposit() and withdraw(). 
//Create a subclass called SavingsAccount that overrides the withdraw() method to prevent withdrawals if the account balance falls below one hundred.
package bankaccountinheritance;

public class bankAccount {
	int initialbalance = 500;
	int DepositAmount = 10000;
	int withdrawAmount = 99;

	
protected void deposit() {
	
	System.out.println("Having deposit amount of "+DepositAmount );
}
protected void withdraw() {
	
	System.out.println("Need to withdraw "+withdrawAmount );
}

	public static void main(String[] args) {
		bankAccount details = new bankAccount();
		System.out.println("current balance "+details.initialbalance);
		details.deposit();
		details.withdraw();

	}

}
