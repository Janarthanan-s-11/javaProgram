package bankaccountinheritance;
//Create a subclass called SavingsAccount that overrides the withdraw() method 
//to prevent withdrawals if the account balance falls below one hundred.
public class savingAccount extends bankAccount {

	public void restrict() {
		
		if(initialbalance<100) {
			System.out.println("Due to insufficent balance rupees "+withdrawAmount+" withdraw not allowed");
		} 
		else {
			System.out.println("Given amount "+withdrawAmount+" withdraw successfully");
		}
		
	}
	public void newbalance() {
		if(initialbalance>=100) {
		int balance = initialbalance+DepositAmount-withdrawAmount;
		System.out.println("your new balance is "+balance);
		}
		else {
			System.out.println("insufficent balance");
		}
	}
	public static void main(String[] args) {
		savingAccount action = new savingAccount();
		action.restrict();
		action.newbalance();

	}

}
