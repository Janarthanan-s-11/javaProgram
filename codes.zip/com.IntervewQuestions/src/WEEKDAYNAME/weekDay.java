//Write a program to read a weekday number and print weekday name using switch statement
package WEEKDAYNAME;

public class weekDay {

	int weekDays = 6;
	
	public void findWeekDay() {
		
		switch(weekDays) {
		case 0:
			System.out.println("WeekDay "+0+ " is Monday" );
			break;
		case 1:
			System.out.println("WeekDay "+1+ " is Tuesday");
			break;
		case 2:
			System.out.println("WeekDay "+2+ " is Wednesday");
			break;
		case 3:
			System.out.println("WeekDay "+3+ " is Thursday" );
			break;
		case 4:
			System.out.println("WeekDay "+4+ " is Friday");
			break;
		case 5:
			System.out.println("WeekDay "+5+ " is Saturday");
			break;
		case 6:
			System.out.println("WeekDay "+6+ " is Sunday");
		}
		
	}
	
	public static void main(String[] args) {
		weekDay Input = new weekDay();
		Input.findWeekDay();
		

	}

}
