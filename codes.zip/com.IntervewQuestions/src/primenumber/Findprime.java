package primenumber;

public class Findprime {
  int bike = 2;
  int car = 3;
  int sum = bike+car;
  int sub = bike - car;
  int mult = bike*car;
  int div = car/bike;
  int quot = car%bike;
  
 public void operations() {
	 System.out.println("Sum "+sum);
	 System.out.println("Sum "+sub);
	 System.out.println("Multiply "+mult);
	 System.out.println("Div "+div);
	 System.out.println("Quote "+quot);
	 
 }
	public static void main(String[] args) {
		Findprime output = new Findprime();
		output.operations();
		 

	}

}
