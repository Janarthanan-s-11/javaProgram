package Biggernumber;
//Check whether an alphabet is vowel or consonant using if..else statement.
public class vowelOrNot {

char input = 'b';
 public void compare() {
	 if (input == 'a'|| input == 'e' || input == 'i' || input =='o'|| input == 'u') {
		 System.out.println("The given character "+input+" is vowel" );
		
	 }
	 else {
		 System.out.println("The given character "+input+" is consonant");
	 }
	 
 }

	public static void main(String[] args) {
		vowelOrNot Result = new vowelOrNot();
		
		Result.compare();
	}

}
