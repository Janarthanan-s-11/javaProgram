package Biggernumber;
//Write a program to take input age of male or Female and check he/she is eligible for marriage or not.
public class EligibleOrNot {
	
	String gender = "male";
	int age = 18;

	public void Check() {
		if(age>17) {
			System.out.println("As per Indian government this "+gender+" is eligible for marriage");
		}
		else if(age<17) {
			System.out.println("As per Indian government this "+gender+" is not eligible for marriage");
		}
		else {
			System.out.println("As per Indian government this "+gender+" is need to wait 1 more year to get eligible for marriage");
		}
	}
	
	public static void main(String[] args) {
		EligibleOrNot congrats = new EligibleOrNot();
		congrats.Check();

	}

}
