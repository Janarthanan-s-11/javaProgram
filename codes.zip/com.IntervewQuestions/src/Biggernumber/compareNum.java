package Biggernumber;
//Write a program to take two number from user and check who is max.
public class compareNum {
	
	int a = 15;
	int b = 15;
	
	public void MaxNumber() {
		
		if (a>b) {
			System.out.println("Value of "+ a + " Is bigger than "+ b);
			}
		else if(b>a) {
			System.out.println("Value of "+b+" is bigger than "+a);
		}
		else {
			System.out.println("Both "+a+" and "+b+" are same");
		}
		}

	public static void main(String[] args) {
		compareNum biggerNumber = new compareNum();
		biggerNumber.MaxNumber();

	}

}
