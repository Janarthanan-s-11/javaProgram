package stringinterviewquestion;

public class stringvaluechange {

	public static void main(String[] args) {
		String name = "superman";//--declarization, if we give value to int then it is initialization
		name = "spiderman";//--re initialization
		System.out.println(name);
		//string is immutable, which means it is constant and value cannot be changed using string operations, but we can reinitialize it
		
		
//String is immutable means that you cannot change the object itself, but you can change the reference to the object. 
		//Changing an object means to use its methods to change one of its fields.
	}

}
