module com.collectmoney {
}