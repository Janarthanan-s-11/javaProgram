package CollectMoneyReturn;

public class collectedAmount {
	
	Integer amount = 1000;
	
 public Integer collectedAndGiven() {
	 System.out.println("Dad he have "+ amount);
	 return amount;
 }

	public static void main(String[] args) {
		collectedAmount mySon = new collectedAmount();
		Integer Got = mySon.collectedAndGiven();
		System.out.println("Dad i have collected amount from him and send you "+Got);

	}

}
