package studentName;

public class student {
	
	Integer studentRoll;
	int studentId;
	String studentName;
	boolean presentOrAbsent;
	//here we didn't give value for the data types
// Constructor should not have return type
	public static void main(String[] args) {
		student Student = new student();
		// class name and constructor name should be same
		//now we will print all three datatypes, Complier should response default values for those data types like O, Null
		System.out.println("Default value for Integer is "+ Student.studentRoll);
		System.out.println("Default value for int is "+ Student.studentId);
		System.out.println("Default value for String is "+ Student.studentName);
		System.out.println("Default value for boolean is "+ Student.presentOrAbsent);
		
		
	}

}
