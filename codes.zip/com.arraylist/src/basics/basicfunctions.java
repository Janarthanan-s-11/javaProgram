package basics;
//array list is used to perform search operation simple
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class basicfunctions {
//create a function
	public void operationofarraylist() {
		//list <datatype> arraylistname = new arraylist<datatype>();  //here the <datatype> is generica
		//Generic is before execution we predict the input and output should be our given datatype
		List<String> basicopertation = new ArrayList<String>();
		basicopertation.add("Batman");
		basicopertation.add("Superman");
		basicopertation.add("Antman");
		basicopertation.add("Superman");  //arraylist can allow duplicate values
		basicopertation.add(null); //we can also add null
		System.out.println(basicopertation);
		System.out.println(basicopertation.indexOf("Superman"));
		System.out.println(basicopertation.lastIndexOf("Superman")); //to identify last index if array as duplicate value
		
		System.out.println(basicopertation.get(2)); //to get value
		System.out.println(basicopertation.contains("batman")); //case sensitive
		
		basicopertation.remove(3); //remove by index
		basicopertation.remove(null); //remove by object, method overloading
		System.out.println(basicopertation);
		
		List<String> basicopertation1 = new ArrayList<String>(); //to copy all values from one arraylist to another
		basicopertation1.addAll(basicopertation);
		System.out.println(basicopertation1);
		
		basicopertation.clear();  //will clear all the values
		System.out.println(basicopertation);
		System.out.println(basicopertation.isEmpty()); //check empty or not
		
		basicopertation1.set(0, "Spiderman"); //to change existing value of index
		System.out.println(basicopertation1);
		
		//iterate
		for (String string : basicopertation1) { //to print all values of array sepratly using for iterate
			System.out.println(string);			
		}
		basicopertation1.add(null);
		for (String string : basicopertation1){
			System.out.println(basicopertation1);  //to print duplicate ouput based on no.of index
		}
	}
	public static void main(String[] args) {
		basicfunctions add = new basicfunctions();
		add.operationofarraylist();
		

	}

}
