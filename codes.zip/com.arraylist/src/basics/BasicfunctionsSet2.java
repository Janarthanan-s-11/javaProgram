package basics;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class BasicfunctionsSet2 {

	public static void main(String[] args) {
		
		List<String> Vegtables = new ArrayList<String>();
		Vegtables.add("Carrot");
		Vegtables.add("Beans");
		Vegtables.add("potato");
		Vegtables.add("tomoto");
		Vegtables.add("onion");
		
		//need to print individual string in list using for loop, for each and list iterator
		
		//forloop --- for(int i=index position; i<arraylistname.loop till array list end value;indexposition++)
		for(int i=0; i<Vegtables.size();i++) {
			//System.out.println(Vegtables); //This will print the array for i number of times
			System.out.println(Vegtables.get(i)); //this will print array string one by one
		}
		System.out.println("-----------------------------------------------------");
		
		//for each -- for(dataype variable : arraylist){print(variable)}
		for(String string : Vegtables) {
		//System.out.println(Vegtables); //This will print the array until it index value
		System.out.println(string); //this will print array string one by one
		
	}
		System.out.println("-----------------------------------------------------");
		
		
		//list iterator -- listiterator<E> iterator = arraylistname.listiterator();
		ListIterator<String> list_iterator = Vegtables.listIterator();
		while(list_iterator.hasNext()) {   //while(perform loop till iterator has next value)
			System.out.println(list_iterator.next()); //print iterator next value from 0.
		}
		System.out.println("-----------------------------------------------------");
		//we can also perform reverse print using list iterator
		while(list_iterator.hasPrevious()) {
			System.out.println(list_iterator.previous());
		}
		System.out.println("-----------------------------------------------------");
		
		
		//iterator- will permform only forward, but list iterator can do forward as well as reverse
		
		Iterator<String> iterator = Vegtables.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next()); 
		}
		
		//array list throw exception when we try to perform multi thread operation, eg: while print if we perform add new string, then it will display error
		for(String string : Vegtables) {
			System.out.println(Vegtables);
			Vegtables.add("gabage");  //---concurrent modification exception
		}
	
}

}
