package difference;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class Differencebetweenthem {
//Duplicate values will not allowed means, will not considered
	public static void main(String[] args) {
		TreeSet<String> movietreeset = new TreeSet<String>();
		movietreeset.add("Dark knight");
		movietreeset.add("IP MAN");
		movietreeset.add("Man of streel");
		movietreeset.add("Joker");
		movietreeset.add("Joker");
		//movietreeset.add(null); not support null, due to treemap will store element based on compared
		System.out.println("Watch movies order like treeset"+movietreeset); //will maintain natural order
		
		LinkedHashSet<String> movielinkedhashset = new LinkedHashSet<String>();
		movielinkedhashset.add("Dark knight");
		movielinkedhashset.add("IP MAN");
		movielinkedhashset.add("Man of streel");
		movielinkedhashset.add("Joker");
		movielinkedhashset.add("Joker");
		movielinkedhashset.add(null);
		System.out.println("Watch movies order like linkedhashset"+movielinkedhashset); //will maintain insertion order
		
		HashSet<String> movieHashset = new HashSet<String>();
		movieHashset.add("Dark knight");
		movieHashset.add("IP MAN");
		movieHashset.add("Man of streel");
		movieHashset.add("Joker");
		movieHashset.add("Joker");
		movielinkedhashset.add(null);//not considered
		System.out.println("Watch movies order like hashset"+movieHashset); //will not maintain any order
		
		
	}

}
