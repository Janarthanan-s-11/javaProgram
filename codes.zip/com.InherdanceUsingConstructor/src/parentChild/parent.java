package parentChild;

public class parent {
//1.parent class no need main method, Now create a constructor
	public parent() {
		// 2.Constructor should not have return type, But it can have public
		System.out.println("Parent class");
	}
}
