package parentChild;

public class childClass extends parent{
	//3.Child class should have main method, Create a constructor
	
	public childClass() {
		//super()
		System.out.println("Child class");
	}

	public static void main(String[] args) {
		// 4.Create a object
		childClass Children = new childClass();
		//5.now run the program
		//6.Now add a extend key in child class "public class childClass extends parent{}"--line 3
		//Now run the program
		//Reason, whenever extends key is added, then super() key will automatically call hiddenly in line 7

	}

}
