module com.InherdanceUsingConstructor {
}