//Rules given by parent for childrens marriage
package overRidingpolymorphism;

public class rulesAndBenifitsOfMarriage {
// need to create methods
	public void benifits() {
		System.out.println("parent : Take our properties");
	}
	public void rules() {
		System.out.println("parent :Must marry the person chosen by us");
	}
	
	
}
