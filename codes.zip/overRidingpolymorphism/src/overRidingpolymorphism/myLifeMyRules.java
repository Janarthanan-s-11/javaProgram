package overRidingpolymorphism;
import overRidingpolymorphism.rulesAndBenifitsOfMarriage; //import packageName.className
public class myLifeMyRules extends rulesAndBenifitsOfMarriage {

//need to copy paste same method from parents---condition of overriding	
	public void benifits() {
		System.out.println("parent : Take our properties");
	}
//Child is not happy with parent decision, so child now can override parent method--Use of overriding.
//need to import override by entering @overriding	
	@Override
	public void rules() {
		System.out.println("child : I will select my partner");
	}	
	public static void main(String[] args) {
//overriding object syntax is parentclassname objname = new childclassname();		
		rulesAndBenifitsOfMarriage myLife = new myLifeMyRules();
		myLife.benifits();
//for regular inharitance we can use parentclassname objname = new parentclassname();		
		rulesAndBenifitsOfMarriage ourdecision = new rulesAndBenifitsOfMarriage();
		ourdecision.rules();
		myLife.rules();	
	}
}
