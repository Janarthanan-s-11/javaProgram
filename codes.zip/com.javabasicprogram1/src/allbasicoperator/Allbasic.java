package allbasicoperator;



public class Allbasic {
	
	int bike = 2, car = 4;
	  int sum = bike+car;
	  int sub = bike - car;
	  int mult = bike*car;
	  int qu = car/bike;
	  int remainder = car%bike;
		  
		 public void operations() {
			 System.out.println("Sum "+sum);
			 System.out.println("Sum "+sub);
			 System.out.println("Multiply "+mult);
			 System.out.println("qu "+qu);
			 System.out.println("Remainder "+remainder);
			 
		 }
			public static void main(String[] args) {
				Allbasic output = new Allbasic();
				output.operations();
				 
	}
}


