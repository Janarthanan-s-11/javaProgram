module com.javabasicprogram1 {
}