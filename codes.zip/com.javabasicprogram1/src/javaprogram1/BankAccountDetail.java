package javaprogram1;

public class BankAccountDetail {
	
	Long accountNumber = 64523848483l;
	String userName = "batman";
	int balance = 50000000;
	
	public void getBalance() {
		
		System.out.println("Account number"+" "+accountNumber);		
		System.out.println("Account owner name"+" is "+ userName);
		System.out.println("Bank balance"+" "+ balance);
		
	}
	

	public static void main(String[] args) {
		// Classname objname = new Classname();
		
		BankAccountDetail account = new BankAccountDetail();
		account.getBalance();

	}

}
