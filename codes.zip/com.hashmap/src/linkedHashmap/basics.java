package linkedHashmap;

import java.util.HashMap;
import java.util.LinkedHashMap;

//only difference between hashmap and linked hashmap is, linked hashmap will maintain insertion order.
public class basics {

	public static void main(String[] args) {
	LinkedHashMap<String, String> MovieNameandHero = new LinkedHashMap<String, String>();
	MovieNameandHero.put("Leo", "Vijay");
	MovieNameandHero.put("Valimai", "Ajith");
	MovieNameandHero.put("Jailer", "Rajini");
	MovieNameandHero.put(null, null);
	System.out.println(MovieNameandHero); //will maintain insertion order
	
	//Hashmap
	HashMap<String, String> movieNameandHeroHashMap = new HashMap<String, String>();
	movieNameandHeroHashMap.put("Leo", "Vijay");
	movieNameandHeroHashMap.put("Valimai", "Ajith");
	movieNameandHeroHashMap.put("Jailer", "Rajini");
	movieNameandHeroHashMap.put(null, null);
	System.out.println(movieNameandHeroHashMap); //will not maintain insertion order.

	}

}
