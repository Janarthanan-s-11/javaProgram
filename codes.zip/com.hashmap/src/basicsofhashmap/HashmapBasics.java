package basicsofhashmap;

import java.util.HashMap;
//Hashmap will allow one null element
// the difference between hashmap and hashset is, hashmap will store element in key and value.
//Key will not allow duplicate but value can, rest all are same, like hashset- will not maintain insertion order
public class HashmapBasics {

	public static void main(String[] args) {
		//HashMap<k,v> variable = new HashMap<k,v>();
		HashMap<Integer, String> StudentIDCard = new HashMap<Integer, String>();
		//In hashmap always element will get entry not add, so we need to use put to enter the element
		StudentIDCard.put(001, "Dhoni");
		StudentIDCard.put(007, null);
		StudentIDCard.put(002, "Sachin");
		StudentIDCard.put(000, "Dravid");
		StudentIDCard.put(004, "Kholi");
		StudentIDCard.put(005, "Rohit sharma");
		StudentIDCard.put(006, "Dhoni");
		System.out.println("Input "+StudentIDCard);//output will be set
		System.out.println("To check whether map having this 005 key "+StudentIDCard.containsKey(005));
		System.out.println("To check whether map having this rohit sharma value "+StudentIDCard.containsValue("rohit sharma"));//case sensitive
		System.out.println("To get the keys available in the map "+StudentIDCard.keySet());
		System.out.println("To get values available in the map" +StudentIDCard.values());
		System.out.println("To get all key and values "+StudentIDCard.entrySet());//output will be list
		//we can get value only by key
		System.out.println("To get value of 004 "+StudentIDCard.get(004));
		//to copy one map to another
		HashMap<Integer, String> StudentIDCard1 = new HashMap<Integer, String>();
	StudentIDCard1.putAll(StudentIDCard);
	System.out.println(StudentIDCard1);
StudentIDCard1.clear();
System.out.println("Clear result of stundentIDCard1 is "+StudentIDCard1);
		

	}

}
