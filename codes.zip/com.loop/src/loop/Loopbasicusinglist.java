package loop;

import java.util.ArrayList;
import java.util.List;

public class Loopbasicusinglist {
 //need to identify the size of the list and nee to print all the elements in the list
	public static void main(String[] args) {
		List<Integer> numbers = new ArrayList<Integer>();
		numbers.add(0);
		numbers.add(1);
		numbers.add(2);
		numbers.add(3);
		numbers.add(4);
		numbers.add(5);
		System.out.println("Values in list "+numbers);
		System.out.println("Size of the list is "+numbers.size());
		//need to print individual elements using for loop
		for(int i = 0; i < numbers.size(); i++) {
			
		}
		
	}

}
