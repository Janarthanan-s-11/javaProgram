package loop;

public class loopbasicusingstring {
      static int i = 0;
      static String name = "batman";
	public static void main(String[] args) {
		for(i = 0; i< 5 ; i++) {
			System.out.println("Print name for 5 times using for loop "+name);
			
		}//now i value becomes 5, we again need to initialize 0 for i.
		System.out.println("The value of i became "+i+" so coming out from for loop");
		i = 0;
		while(i < 5) {
			System.out.println("Print name for 5 times using while loop"+name);
			i++;
			
		}
		System.out.println("The value of i became " + i + " that is why it broke out of the while loop");
	//now i value becomes 5, but do while will print once and will check the condition.
	
	do {
		System.out.println("Print name for 5 times using do while loop" +name);
		i++;
	}while(i < 5);
	System.out.println("The value of i became " + i + " that is why it broke out of the do while loop");
}
	

}
