package opendifferentbrowsers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

//1.Launch chrome, search got google, bing and yahoo websites and calculate time take for it
public class Withoutframework {
//1.Launch browser and search google
	
	@Test
	public void searchGoogle() {
		//to get time, we need to use system.currentimemillis method, because we need to calculate from system level
	long startimeforgoogle =	System.currentTimeMillis(); //time will always calculate in system level
		
		//1.Tell system, where is our driver located
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		//launch chrome
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.google.com/");
		driver.quit();
	long endtimeforgoogle =	System.currentTimeMillis();
	long totaltimeforgoogleis = endtimeforgoogle-startimeforgoogle;
	System.out.println("Time taken to load google is "+totaltimeforgoogleis);
	}
	@Test
	public void searchbing() {
		long startimeforbing =	System.currentTimeMillis();
		//1.Tell system, where is our driver located
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		//launch chrome
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.bing.com/");
		driver.quit();
		long endtimeforbing =	System.currentTimeMillis();
		long totaltimeforbingis = endtimeforbing-startimeforbing;
		System.out.println("Time taken to load bing is "+totaltimeforbingis);
	}
	@Test
	public void searchyahoo() {
		long startimeforyahoo =	System.currentTimeMillis();
		//1.Tell system, where is our driver located
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		//launch chrome
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.yahoo.com/");
		driver.quit();
		long endtimeforyahoo =	System.currentTimeMillis();
		long totaltimeforyahoo = endtimeforyahoo-startimeforyahoo;
		System.out.println("Time taken to load yahoo is "+totaltimeforyahoo);
	}
}
	//totally is taen 4349+2456+4419 = 11224milliseconda = 11seconds
	