package opendifferentbrowsers;
//1.now we will perform same open a browser and search google, bing, yahoo and calculate the time with test suite

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class WithtestSuite {
//1.Launching chrome and calculating time is system level, so we can give them as global variable
	//global variable - we need to declare inside the class
	 WebDriver driver; //global variable
	 long starttime;  //global variable
	 long endtime;  //global variable
//2. we need to open browser before test got execute and quit is after test got execute, so we create it has begin and end 
	 @BeforeSuite       //---will perform before executing the suite(Test scenarios)
	 public void launchbrowser() {
		 starttime = System.currentTimeMillis();
		 System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		 driver = new ChromeDriver();
	 }
//3. now perform test scenarios, search URL's one by one
	 @Test
	 public void searchgoogle() {
		 long starttimeforchrome = System.currentTimeMillis(); //local(within the method)
		 driver.get("https://www.google.com/");
		 long endtimeforchrome = System.currentTimeMillis();
		 long timetakeforchrome = endtimeforchrome-starttimeforchrome;
			System.out.println("Time take to search google "+timetakeforchrome);
	 }
	 @Test
	 public void searchbing() {
		 long starttimeforbing = System.currentTimeMillis();
		 driver.get("https://www.bing.com/");
		 long endtimeforbing = System.currentTimeMillis();
		 long timetakeforbing = endtimeforbing-starttimeforbing;
			System.out.println("Time take to search bing "+timetakeforbing);
	 }
	 @Test
	 public void searchyahoo() {
		 long starttimeforyahoo = System.currentTimeMillis();
		 driver.get("https://www.yahoo.com/");
		 long endtimeforyahoo = System.currentTimeMillis();
		 long timetakeforyahoo = endtimeforyahoo-starttimeforyahoo;
			System.out.println("Time take to search yahoo "+timetakeforyahoo);
	 }

	 
//4.need to quit browser
	 @AfterSuite
	 public void quit() {
		 driver.quit();
		endtime = System.currentTimeMillis();
		long timetake = endtime-starttime;
		System.out.println("Time take to search all browser "+timetake);
	 }
	//now it take only 7second for whole operation
	
	
}
