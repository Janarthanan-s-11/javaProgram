package testngoperations;

import org.testng.annotations.Test;



//1.to get work, condidate must get pass in high school, higher secondary school and college
//2.if he failed, then we is not eligible for this work
public class Dependencymethod {
//1.we need to priority, but it will not check the condition, so for that we need to create dependency for method
	@Test (priority = 0, enabled = true) //we have customized from where the execution to be started and gave conditions as true
	public void SSLC() {
		System.out.println("Yes, he got pass in sslc");
	}
	
	
	@Test (dependsOnMethods = "SSLC", enabled = true) //if, Enable is false, then he got failed in highsecondary, not SSLC.
	public void Highsecondary() {
		System.out.println("Yes, he got pass in 12th");
	}
	
	
	@Test (dependsOnMethods = "Highsecondary", enabled = true)
	public void college() {
	System.out.println("Yes, he got pass in college");		
	}
	
	
	@Test (dependsOnMethods = "Highsecondary", enabled = true)
	public void iseligibleforwork() {
		System.out.println("Yes, he is eligible for this work");
	}
	
	
}
