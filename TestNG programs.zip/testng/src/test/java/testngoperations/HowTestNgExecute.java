package testngoperations;

import org.testng.annotations.Test;

public class HowTestNgExecute {
//TestNG will always execute in alphabetic order..//to avoid the alphabet execution we can customize it using prioirty
	//we need to drive a bike in 150kmph
	@Test (priority = 0) //this is used to prioritize which method we need to execute first
	public void starttheBike() {
		System.out.println("Bike got started");
	}
	@Test (priority = 1)
	public void Put1stgear() {
		System.out.println("Bike speed is 30");
	}
	@Test (priority = 2)
	public void Putsecondgear() {
		System.out.println("Bike speed is 50");
	}
	
	//to skip some test case, then we need to use enabled boolean method, by default it is true
	@Test (priority = 3, enabled = false)
	public void givefullthrottle() {
		System.out.println("Reached RPM level");
	}
	
	@Test (priority = 4)
	public void Putthirstgear() {
		System.out.println("Bike speed is 90");
	}
	@Test (priority = 5)
	public void Put4rthgear() {
		System.out.println("Bike speed is 110");
	}
	@Test (priority = 6)
	public void Put5thgear() {
		System.out.println("Bike speed is 125");
	}
	@Test (priority = 7)
	public void Putsixthgear() {
		System.out.println("Bike speed is 150");
	}
	
}
