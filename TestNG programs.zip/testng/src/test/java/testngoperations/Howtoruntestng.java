package testngoperations;

import org.testng.annotations.Test;

//testng we no need main method
public class Howtoruntestng {

	@Test
	public void print1() {
		System.out.println("Print 1");
	}
	@Test
public void print2() {
		System.out.println("Print 2");
	}
	//import testng in beginning to execute
}
