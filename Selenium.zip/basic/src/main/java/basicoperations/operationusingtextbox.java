package basicoperations;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//program failed due to ACR element find
public class operationusingtextbox {
//clear the sunday position value and update it
	public static void main(String[] args) {
		//1.tell which browser and location of it to program
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
    ChromeDriver driver = new ChromeDriver();
    //2.Launch URL
    driver.get("https://aks-acr-qa.hospitalityrevolution.com/#/18195");
    WebElement userID = driver.findElement(By.id("InputuserId"));
    userID.sendKeys("jana");

    WebElement password = driver.findElement(By.id("InputPassword"));
    password.sendKeys("Jana@12345");
 WebElement loginButton =  driver.findElement(By.xpath("//*[@id=\"ngbtn-lc-loginactshow\"]"));
    loginButton.click();
  //for find xpath--  //xmlcodebegin['@attribute=value']
 WebElement logintoasted =   driver.findElement(By.xpath("//*[@id=\"toast-container\"]/div/div"));
 logintoasted.isDisplayed();
    //3.Navigate to settings page and cleat primary and secondary color value
 
  
 WebElement tenentconfig = driver.findElement(By.xpath("//*[@id=\"nglbl-lc-sidemenu\"]/app-settings/div/div[1]/div[1]"));
 tenentconfig.click();
 
 WebElement sundayposition = driver.findElement(By.xpath("//*[@id=\"mat-input-72\"]"));
 sundayposition.clear();
 sundayposition.sendKeys("2");
 
 WebElement savedetailsbutton = driver.findElement(By.xpath("//*[@id=\"btn-sec-save-can\"]/div/button[2]/span[1]"));
 savedetailsbutton.click();
 
 driver.close();
 
	}

}
