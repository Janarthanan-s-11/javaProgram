package basicoperations;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Radiobutton {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.leafground.com/radio.xhtml");
		//radio button
	WebElement favBrowser =	driver.findElement(By.xpath("//*[@id=\"j_idt87:console1\"]/tbody/tr/td[1]/div/div[2]/span"));
		favBrowser.click();
		
		//1.find default selected option in it
		
	WebElement 	chrome = driver.findElement(By.xpath("/html/body/div[1]/div[5]/div[2]/form/div/div[2]/div[1]/div/div/table/tbody/tr/td[1]/div/div[2]"));
	Boolean defaultischrome =	chrome.isSelected();
	System.out.println("Chome "+defaultischrome);
		WebElement 	fireFox = driver.findElement(By.xpath("/html/body/div[1]/div[5]/div[2]/form/div/div[2]/div[1]/div/div/table/tbody/tr/td[2]/div/div[2]"));
		Boolean defaultisfireFox =	fireFox.isSelected();
		System.out.println("Firefox "+defaultisfireFox);
		WebElement 	safari = driver.findElement(By.xpath("//*[text()='Find the default select radio button']/following-sibling::div//*[text()='Safari']/preceding-sibling::div/div/input"));
		Boolean defaultissafari =	safari.isSelected();
		System.out.println("safari "+defaultissafari);
		WebElement 	edge = driver.findElement(By.xpath("/html/body/div[1]/div[5]/div[2]/form/div/div[2]/div[1]/div/div/table/tbody/tr/td[4]/div/div[2]"));
		Boolean defaultisedge =	edge.isSelected();
		System.out.println("edge "+defaultisedge);
		//2.need to select chrome
		Thread.sleep(500);
		if(defaultisfireFox=true) {
			System.out.println("Default browser is firefox");
			chrome.click();
		}else if (defaultischrome = true) {
			System.out.println("Default browser is chrome");
			chrome.click();
		} else if (defaultissafari = true) {
			System.out.println("Default browser is safari");
			chrome.click();
		} else if (defaultisedge = true) {
			System.out.println("Default browser is edge");
			chrome.click();
			
		} 

		
		//some issue woth browser, end result is pass but if conditions getting failed


	}

	private static void ifelse(Boolean boolean1) {
		// TODO Auto-generated method stub
		
	}

}
