package basicoperations;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropdownoperationusingFB {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com");
		//for find xpath--  //xmlcodebegin['@attribute=value']
	WebElement createNewaccount =	driver.findElement(By.xpath("//a[@class=\"_42ft _4jy0 _6lti _4jy6 _4jy2 selected _51sy\"]"));
	createNewaccount.click();
	//create select operation for dropdowns;

	Thread.sleep(1000);
	

	WebElement Daydropdown =	driver.findElement(By.id("day"));

//selectclass variable = new selectclass;
		Select select = new Select(Daydropdown);
		select.selectByIndex(0);
		Thread.sleep(1000);
		select.selectByIndex(22);
		Thread.sleep(1000);
		select.selectByVisibleText("18");
		Thread.sleep(1000);
		//we can also select dropdown using value
		Daydropdown.sendKeys("20");
		
		//to get all available option under the dropdown, we need to use list, we can know it by place curson on getoption
	List<WebElement> availableoptions =	select.getOptions();
int available =	availableoptions.size();
System.out.println("Available options under the dropdown is "+available);


	
	}

}
