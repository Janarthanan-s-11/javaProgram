package basicoperations;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class operationusingdropdown {

	public static void main(String[] args) throws InterruptedException {
		 System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		 ChromeDriver driver = new ChromeDriver();
		 driver.get("https://aks-acr-qa.hospitalityrevolution.com/#/18195");
		 WebElement loginButton = driver.findElement(By.xpath("//*[@id=\"ngbtn-lc-loginactshow\"]"));
		 
		//for find xpath--  //xmlcodebegin['@attribute=value']
		 WebElement userID = driver.findElement(By.id("InputuserId"));
		 userID.sendKeys("jana");

		 WebElement password = driver.findElement(By.id("InputPassword"));
		 password.sendKeys("Jana@12345");

		 loginButton.click();
		 
		 //for wait global level
		// driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(35));
		 
		 Thread.sleep(5000);
		 
		 //1.in dashboard page, select any agent for dropdown and save it
	WebElement agentdropdown =	 driver.findElement(By.xpath("//*[@id=\"mat-select-2\"]/div/div[2]"));
boolean isdisplay =	agentdropdown.isDisplayed();
agentdropdown.click();
System.out.println(isdisplay);
 //to select value in dropdown, need to to create object for select class
//class variable = new class(webelement)
/*
Select select = new Select(agentdropdown);
select.selectByValue("mat-option-609"); */
//due to we have dropdown+checkbox, we are going for normal operation		 

WebElement dropdownValue = driver.findElement(By.xpath("//*[@id=\"mat-option-609\"]/mat-pseudo-checkbox"));
dropdownValue.click();	
//click save button
WebElement DUMMYACTION = driver.findElement(By.xpath("//div[@class=\"cdk-overlay-backdrop cdk-overlay-transparent-backdrop cdk-overlay-backdrop-showing\"]"));
DUMMYACTION.click();
Thread.sleep(3000);
WebElement savepreference = driver.findElement(By.id("btn-adm-dshbd-save-pref"));
savepreference.click();








	}

}
