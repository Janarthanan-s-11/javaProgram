package basicoperations;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckBoxbasics {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.leafground.com/checkbox.xhtml;jsessionid=node010nx464jtc8vzxsmrg4fp0yu9138.node0");
		WebElement basic = driver.findElement(By.xpath("//*[@id=\"j_idt87:j_idt89\"]/div[2]"));
		basic.click();
		WebElement notificationcheckbox = driver.findElement(By.xpath("//*[@id=\"j_idt87:j_idt91\"]/div[2]"));
		notificationcheckbox.click();
		
		Thread.sleep(500);
		
	WebElement toastedmessage =	driver.findElement(By.xpath("//*[@id=\"j_idt87:msg_container\"]/div/div/div[2]/span"));
Boolean message =		toastedmessage.isDisplayed();
System.out.println("is toasted message is displayed "+message);
	WebElement toggleSwitch =	 driver.findElement(By.id("j_idt87:j_idt100"));
	toggleSwitch.click();
	Thread.sleep(500);
		 
	//SELECT ALL CHECKBOX
	//TRISTATE
	//SELECT MULTIPLE ARE PENDING
	
	

	}

}
