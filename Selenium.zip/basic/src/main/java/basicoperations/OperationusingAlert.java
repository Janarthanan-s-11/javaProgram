package basicoperations;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class OperationusingAlert {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("Webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.leafground.com/alert.xhtml");
		
		
	WebElement simpleDialog =	driver.findElement(By.xpath("//*[@id=\"j_idt88:j_idt91\"]/span[2]"));
	Thread.sleep(1000);
	simpleDialog.click();
	//alert, the control will be switch from browser to alert, so for alerts we need to use alert interface
			//note= for interface we should not create object
	//Alert variable = driver.switch().alert
	 Alert simplealert = driver.switchTo().alert();
	 Thread.sleep(1000);
		//simpledialog alert having only ok, so we need to perform accept action
	 simplealert.accept();
	 
WebElement confirmDialog =	driver.findElement(By.xpath("//*[@id=\"j_idt88:j_idt93\"]/span[2]"));
confirmDialog.click();
Thread.sleep(1000);
Alert confirmalert = driver.switchTo().alert();
//here we need to click cancel button, so we need to use dismiss.
confirmalert.dismiss();
WebElement propmt = driver.findElement(By.xpath("//*[@id=\"j_idt88:j_idt104\"]/span[2]"));
propmt.click();
Thread.sleep(1000);
Alert promptalert = driver.switchTo().alert();
promptalert.sendKeys("Ok, allow them"); //prompt we need to enter text and click ok
promptalert.accept();
 
	
		
	}

}
