package basicoperations;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class openbrowserandlogin {
//selenium is webapplication automation framework
	public static void main(String[] args) {
		
	//1.set a property to tell program which browser we need and where it is
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		//driver - browser
ChromeDriver driver = new ChromeDriver();
driver.get("https://aks-acr-qa.hospitalityrevolution.com/#/18195");
//to identify the element operation in future, we saving the element into a webelement
//then we performing the operation, to find this we need to place curson on the last operation, it will display whether the return type is string, webelemt or etc

WebElement loginButton = driver.findElement(By.xpath("//*[@id=\"ngbtn-lc-loginactshow\"]"));
Boolean enableornot = loginButton.isEnabled();
System.out.println("Whether login button is enable before enter credentials = "+enableornot);

WebElement userID = driver.findElement(By.id("InputuserId"));
userID.sendKeys("jana");

WebElement password = driver.findElement(By.id("InputPassword"));
password.sendKeys("Jana@12345");

loginButton.click();



	}

}
