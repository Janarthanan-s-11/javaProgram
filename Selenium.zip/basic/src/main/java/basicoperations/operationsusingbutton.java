package basicoperations;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class operationsusingbutton {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		//driver - browser
ChromeDriver driver = new ChromeDriver();
driver.get("https://aks-acr-qa.hospitalityrevolution.com/#/18195");
//to identify the element operation in future, we saving the element into a webelement
//then we performing the operation, to find this we need to place curson on the last operation, it will display whether the return type is string, webelemt or etc

WebElement loginButton = driver.findElement(By.xpath("//*[@id=\"ngbtn-lc-loginactshow\"]"));
Boolean enableornot = loginButton.isEnabled();
System.out.println("Whether login button is enable before enter credentials = "+enableornot);

WebElement userID = driver.findElement(By.id("InputuserId"));
userID.sendKeys("jana");

WebElement password = driver.findElement(By.id("InputPassword"));
password.sendKeys("Jana@12345");

Boolean enableOrNot = loginButton.isEnabled();
System.out.println("After enter credentials, whether buttons enabled "+enableOrNot);

//to find color of the button;
 String colorofbutton = loginButton.getCssValue("background-color");
 System.out.println(colorofbutton);
 
 
 
 //to find size
int height = loginButton.getSize().getHeight();
int width = loginButton.getSize().getWidth();
System.out.println("Height "+height+" width"+width);
//for find xpath--  //xmlcodebegin['@attribute=value']

System.out.println(loginButton.getLocation().toString());


	}

}
